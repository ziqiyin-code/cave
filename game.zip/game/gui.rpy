﻿################################################################################
## Initialization
################################################################################

## The "init offset" statement makes initialization statements in this file run before
## "init" statements in any other file.
init offset = -2

## Calling gui.init resets styles to reasonable defaults and sets the game's width and
## height (the base resolution).
init python:
    gui.init(1920, 1080)

## Enables checks for invalid or unreliable properties in screens or transforms.
define config.check_conflicting_properties = True


################################################################################
## GUI configuration variables
################################################################################


## Colors ##########################################################################
##
## Colors for interface text.

## The accent color used throughout the interface to mark and highlight text.
define gui.accent_color = '#336600'

## The color used for text buttons when neither selected nor hovered.
define gui.idle_color = '#707070'

## The color for small text; it may need to be lighter or darker to achieve the same effect.
define gui.idle_small_color = '#606060'

## The color used when buttons and sliders are hovered.
define gui.hover_color = '#336600'

## The color for a selected but unfocused text button. A button is selected when it
## represents the current screen or a preference value.
define gui.selected_color = '#555555'

## The color used for text buttons that cannot be selected.
define gui.insensitive_color = '#7070707f'

## The colors for the unfilled part of sliders. They are used when regenerating the
## bar image files.
define gui.muted_color = '#84a366'
define gui.hover_muted_color = '#adc199'

## The colors used for dialogue and menu-choice text.
define gui.text_color = '#404040'
define gui.interface_text_color = '#404040'


## Fonts and font sizes #####################################################################

## The font used for in-game text.
define gui.text_font = "SourceHanSansLite.ttf"

## The font used for character names.
define gui.name_text_font = "SourceHanSansLite.ttf"

## The font used for text outside the game.
define gui.interface_text_font = "SourceHanSansLite.ttf"

## The size of ordinary dialogue text.
define gui.text_size = 33

## The size of character names.
define gui.name_text_size = 45

## The size of text in the game interface.
define gui.interface_text_size = 33

## The size of labels in the game interface.
define gui.label_text_size = 36

## The size of text on the notification screen.
define gui.notify_text_size = 24

## The size of the game title.
define gui.title_text_size = 75


## Title and game menus #####################################################################

## Images used by the title and game menus.
define gui.main_menu_background = "images/cave.png"
define gui.game_menu_background = "gui/game_menu.png"


## Dialogue ##########################################################################
##
## These variables control how dialogue is displayed line by line.

## The height of the dialogue box.
define gui.textbox_height = 278

## The textbox's vertical position: 0.0 is the top, 0.5 is centered, and 1.0 is the bottom.
define gui.textbox_yalign = 1.0


## The narrator's name position relative to the textbox. Use an integer pixel offset from
## the left or top, or 0.5 to center it.
define gui.name_xpos = 360
define gui.name_ypos = 0

## Horizontal alignment for character names: 0.0 is left, 0.5 is centered, and 1.0 is right.
define gui.name_xalign = 0.0

## The name box's width, height, and border size, or None to determine its size automatically.
define gui.namebox_width = None
define gui.namebox_height = None

## The name box's borders, ordered left, top, right, and bottom.
define gui.namebox_borders = Borders(5, 5, 5, 5)

## If True, tile the name box background; if False, scale it.
define gui.namebox_tile = False


## The dialogue position relative to the textbox. Use an integer pixel offset from its
## left or top, or 0.5 to center it.
define gui.dialogue_xpos = 402
define gui.dialogue_ypos = 75

## The maximum width of dialogue text, in pixels.
define gui.dialogue_width = 1116

## Horizontal alignment for dialogue text: 0.0 is left, 0.5 is centered, and 1.0 is right.
define gui.dialogue_text_xalign = 0.0


## Buttons ##########################################################################
##
## These variables and the images in gui/button control how buttons are displayed.

## Button width and height in pixels. If None, Ren'Py calculates the size.
define gui.button_width = None
define gui.button_height = None

## Button borders, ordered left, top, right, and bottom.
define gui.button_borders = Borders(6, 6, 6, 6)

## If True, tile the background image; if False, scale it linearly.
define gui.button_tile = False

## The font used by buttons.
define gui.button_text_font = gui.interface_text_font

## The text size used by buttons.
define gui.button_text_size = gui.interface_text_size

## Button text colors for each state.
define gui.button_text_idle_color = gui.idle_color
define gui.button_text_hover_color = gui.hover_color
define gui.button_text_selected_color = gui.selected_color
define gui.button_text_insensitive_color = gui.insensitive_color

## Horizontal alignment for button text: 0.0 is left, 0.5 is centered, and 1.0 is right.
define gui.button_text_xalign = 0.0


## These variables override settings for different button types. See the GUI documentation
## for available button types and their purposes.
##
## These customizations are used by the default interface:

define gui.radio_button_borders = Borders(27, 6, 6, 6)

define gui.check_button_borders = Borders(27, 6, 6, 6)

define gui.confirm_button_text_xalign = 0.5

define gui.page_button_borders = Borders(15, 6, 15, 6)

define gui.quick_button_borders = Borders(15, 6, 15, 0)
define gui.quick_button_text_size = 21
define gui.quick_button_text_idle_color = gui.idle_small_color
define gui.quick_button_text_selected_color = gui.accent_color

## You can add customizations using correctly named variables. For example, uncomment the
## following lines to set the navigation button width.

# define gui.navigation_button_width = 250


## Choice buttons ########################################################################
##
## Choice buttons used by in-game menus.

define gui.choice_button_width = 1185
define gui.choice_button_height = None
define gui.choice_button_tile = False
define gui.choice_button_borders = Borders(150, 8, 150, 8)
define gui.choice_button_text_font = gui.text_font
define gui.choice_button_text_size = gui.text_size
define gui.choice_button_text_xalign = 0.5
define gui.choice_button_text_idle_color = '#707070'
define gui.choice_button_text_hover_color = "#ffffff"
define gui.choice_button_text_insensitive_color = '#7070707f'


## Save-slot buttons ########################################################################
##
## Save-slot buttons are a special type of button. They contain a thumbnail and text
## describing the save, and use images from gui/button like other button types.

## Save-slot buttons.
define gui.slot_button_width = 414
define gui.slot_button_height = 309
define gui.slot_button_borders = Borders(15, 15, 15, 15)
define gui.slot_button_text_size = 21
define gui.slot_button_text_xalign = 0.5
define gui.slot_button_text_idle_color = gui.idle_small_color
define gui.slot_button_text_selected_idle_color = gui.selected_color
define gui.slot_button_text_selected_hover_color = gui.hover_color

## The width and height of save thumbnails.
define config.thumbnail_width = 384
define config.thumbnail_height = 216

## The number of columns and rows in the save grid.
define gui.file_slot_cols = 3
define gui.file_slot_rows = 2


## Positioning and spacing #######################################################################
##
## These variables control the position and spacing of interface elements.

## The navigation buttons' left position relative to the screen's left edge.
define gui.navigation_xpos = 60

## The skip indicator's vertical position.
define gui.skip_ypos = 15

## The notification interface's vertical position.
define gui.notify_ypos = 68

## Spacing between menu choices.
define gui.choice_spacing = 33

## Buttons in the navigation section of the title and game menus.
define gui.navigation_spacing = 6

## The spacing between preference items.
define gui.pref_spacing = 15

## The spacing between preference buttons.
define gui.pref_button_spacing = 0

## The spacing between save-page buttons.
define gui.page_spacing = 0

## The spacing between save buttons.
define gui.slot_spacing = 15

## The position of title-menu text.
define gui.main_menu_text_xalign = 1.0


## Frames ##########################################################################
##
## These variables control frames that can hold interface components when no overlay or
## window is present.

## General frame.
define gui.frame_borders = Borders(6, 6, 6, 6)

## The frame used in the confirm interface.
define gui.confirm_frame_borders = Borders(60, 60, 60, 60)

## The frame used in the skip interface.
define gui.skip_frame_borders = Borders(24, 8, 75, 8)

## The frame used in the notification interface.
define gui.notify_frame_borders = Borders(24, 8, 60, 8)

## Should the frame background be tiled?
define gui.frame_tile = False


## Bars, scrollbars, and sliders ####################################################################
##
## These statements control the appearance and size of bars, scrollbars, and sliders.
##
## The default GUI uses only sliders and vertical scrollbars. All other bars are used only
## in creator-written screens.

## The height of horizontal bars, scrollbars, and sliders; the width of vertical ones.
define gui.bar_size = 38
define gui.scrollbar_size = 18
define gui.slider_size = 38

## If True, tile the bar background; if False, scale it linearly.
define gui.bar_tile = False
define gui.scrollbar_tile = False
define gui.slider_tile = False

## Horizontal borders.
define gui.bar_borders = Borders(6, 6, 6, 6)
define gui.scrollbar_borders = Borders(6, 6, 6, 6)
define gui.slider_borders = Borders(6, 6, 6, 6)

## Vertical borders.
define gui.vbar_borders = Borders(6, 6, 6, 6)
define gui.vscrollbar_borders = Borders(6, 6, 6, 6)
define gui.vslider_borders = Borders(6, 6, 6, 6)

## What to do with unscrollable scrollbars in the game menu. "hide" hides them,
## while None shows them.
define gui.unscrollable = "hide"


## History ##########################################################################
##
## The history screen displays dialogue the player has already read.

## The number of dialogue-history entries Ren'Py will retain.
define config.history_length = 250

## The height of history-screen entries, or None to make their height adapt.
define gui.history_height = 210

## Extra spacing between history-screen entries.
define gui.history_spacing = 0

## The position, width, and alignment of the specified narrator's label.
define gui.history_name_xpos = 233
define gui.history_name_ypos = 0
define gui.history_name_width = 233
define gui.history_name_xalign = 1.0

## The position, width, and alignment of dialogue text.
define gui.history_text_xpos = 255
define gui.history_text_ypos = 3
define gui.history_text_width = 1110
define gui.history_text_xalign = 0.0


## NVL mode ######################################################################
##
## The NVL-mode screen displays dialogue produced by characters in NVL mode.

## The background borders for the NVL-mode window.
define gui.nvl_borders = Borders(0, 15, 0, 30)

## The maximum number of NVL entries Ren'Py displays. If there are more, the oldest
## entries are removed.
define gui.nvl_list_length = 6

## The height of NVL entries. Set this to None to make their height dynamic.
define gui.nvl_height = 173

## When gui.nvl_height is None, the spacing between NVL entries and between entries and
## the NVL menu.
define gui.nvl_spacing = 15

## The position, width, and alignment of the specified narrator's label.
define gui.nvl_name_xpos = 645
define gui.nvl_name_ypos = 0
define gui.nvl_name_width = 225
define gui.nvl_name_xalign = 1.0

## The position, width, and alignment of dialogue text.
define gui.nvl_text_xpos = 675
define gui.nvl_text_ypos = 12
define gui.nvl_text_width = 885
define gui.nvl_text_xalign = 0.0

## The position, width, and alignment of nvl_thought text (text represented by the
## nvl_narrator character).
define gui.nvl_thought_xpos = 360
define gui.nvl_thought_ypos = 0
define gui.nvl_thought_width = 1170
define gui.nvl_thought_xalign = 0.0

## The position of NVL menu buttons.
define gui.nvl_button_xpos = 675
define gui.nvl_button_xalign = 0.0


## Localization #########################################################################

## This variable controls where line breaks are allowed. The default works for most
## languages. See https://
## www.renpy.org/doc/html/style_properties.html#style-property-language

define gui.language = "unicode"


################################################################################
## Mobile devices
################################################################################

init python:

    ## Enlarge quick-menu buttons so they are easier to tap on tablets and phones.
    @gui.variant
    def touch():

        gui.quick_button_borders = Borders(60, 21, 60, 0)

    ## Change GUI element sizes and spacing to make them easier to distinguish on phones.
    @gui.variant
    def small():

        ## Font sizes.
        gui.text_size = 45
        gui.name_text_size = 54
        gui.notify_text_size = 38
        gui.interface_text_size = 45
        gui.button_text_size = 45
        gui.label_text_size = 51

        ## Adjust the dialogue-box position.
        gui.textbox_height = 360
        gui.name_xpos = 120
        gui.dialogue_xpos = 135
        gui.dialogue_width = 1650

        ## Change the size and spacing of each element.
        gui.slider_size = 54

        gui.choice_button_width = 1860
        gui.choice_button_text_size = 45

        gui.navigation_spacing = 30
        gui.pref_button_spacing = 15

        gui.history_height = 285
        gui.history_text_width = 1035

        gui.quick_button_text_size = 30

        ## File-button layout.
        gui.file_slot_cols = 2
        gui.file_slot_rows = 2

        ## NVL mode.
        gui.nvl_height = 255

        gui.nvl_name_width = 458
        gui.nvl_name_xpos = 488

        gui.nvl_text_width = 1373
        gui.nvl_text_xpos = 518
        gui.nvl_text_ypos = 8

        gui.nvl_thought_width = 1860
        gui.nvl_thought_xpos = 30

        gui.nvl_button_width = 1860
        gui.nvl_button_xpos = 30
