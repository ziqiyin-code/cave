﻿## This file contains settings you can customize for your game.
##
## Lines beginning with "##" are comments and should not be uncommented. Lines beginning
## with "#" are commented-out code that you may want to uncomment when appropriate.


## Basics ##########################################################################

## The user-readable game name. It sets the default window title and appears in the
## interface and error reports.
##
## Strings wrapped in _() can be translated.

define config.name = _("cave")
define config.language = "en"


## Determines whether the title above appears on the title screen. Set to False to hide it.

define gui.show_name = True


## The game version number.

define config.version = "1.0"


## Text for the in-game About screen. Put it between triple quotes, leaving a blank line
## between paragraphs.

define gui.about = _p("""
""")


## The short name used for the executable and directory in release builds. Use only ASCII
## characters; do not include spaces, colons, or semicolons.

define build.name = "cave"


## Sound and music #######################################################################

## These three variables control which built-in mixers are shown to users by default.
## Setting one to False hides that mixer.

define config.has_sound = True
define config.has_music = True
define config.has_voice = True


## To let users play test audio on the sound or voice track, uncomment the line below and
## set the sample sound to play.

# define config.sample_sound = "sample-sound.ogg"
# define config.sample_voice = "sample-voice.ogg"


## Uncomment the statement below to set the title-screen background music. It will play
## throughout the game until stopped or another file starts playing.

# define config.main_menu_music = "main-menu-theme.ogg"
define config.main_menu_music = None


## Transitions ##########################################################################
##
## These variables control transitions for certain events. Each should be set to a
## transition, or to None for no transition.

## Entering or leaving the game menu.

define config.enter_transition = dissolve
define config.exit_transition = dissolve


## Transitions between game menus.

define config.intra_transition = dissolve


## The transition used after loading a game.

define config.after_load_transition = None


## The transition used when returning to the main menu after the game ends.

define config.end_game_transition = None


## This variable controls the transition when no start label exists. Instead, use a with
## statement after displaying the initial scene.


## Window management ########################################################################
##
## This controls when the dialogue window appears. With show, it is always visible. With
## hide, it appears only during dialogue. With auto, it hides before scene statements and
## reappears when new dialogue begins.
##
## After the game starts, use window show, window hide, and window auto statements to
## change its state.

define config.window = "auto"


## Transitions for showing and hiding the dialogue window.

define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)


## Defaults ########################################################################

## Controls the default text speed. The default, 0, is instantaneous; other values are
## characters displayed per second.

default preferences.text_cps = 25


## The default auto-forward delay. Higher values wait longer; the valid range is 0 to 30.

default preferences.afm_time = 15


## Save directory ########################################################################
##
## Controls the operating-system-specific directory where Ren'Py stores game saves. Save
## files are placed in:
##
## Windows：%APPDATA\RenPy\<config.save_directory>
##
## Macintosh：$HOME/Library/RenPy/<config.save_directory>
##
## Linux：$HOME/.renpy/<config.save_directory>
##
## This statement usually should not be changed. If changed, use a valid string, not an expression.

define config.save_directory = "cave-1789027670"


## Icon ##########################################################################
##
## The icon shown in the taskbar or Dock.

define config.window_icon = "gui/window_icon.png"


## Build configuration ########################################################################
##
## This section controls how Ren'Py turns your project into a distributable release.

init python:

    ## The following functions accept file patterns. Patterns are case-insensitive and
    ## match relative paths from the base directory, with or without a leading /. The
    ## first matching pattern takes precedence.
    ##
    ## In a pattern:
    ##
    ## / is the directory separator.
    ##
    ## * matches any characters except directory separators.
    ##
    ## ** matches any characters, including directory separators.
    ##
    ## For example, *.txt matches text files in the base directory, game/**.ogg matches
    ## OGG files in the game directory or its subdirectories, and **.psd matches PSD files
    ## anywhere in the project.

    ## List a file as None to exclude it from the release build.

    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)

    ## To package a file, list it as "archive".

    # build.classify('game/**.png', 'archive')
    # build.classify('game/**.jpg', 'archive')

    ## Files matching the documentation pattern are copied into Mac application builds,
    ## so they appear in both the APP and ZIP files.

    build.documentation('*.html')
    build.documentation('*.txt')


## In-app purchases require a Google Play license key. Find it in the Google Play
## Developer Console under "Monetize" > "Monetization Setup" > "Licensing".

# define build.google_play_key = "..."


## The itch.io username and project name, separated by /.

# define build.itch_project = "renpytom/test-project"
